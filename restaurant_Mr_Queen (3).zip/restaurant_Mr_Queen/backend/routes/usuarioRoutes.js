const express = require('express');
const router = express.Router();
const {
  registrarUsuario,
  loginUsuario,
  logoutUsuario,
  me,
  obtenerUsuarios,
  actualizarUsuario,
  eliminarUsuario
} = require('../controllers/usuarioController');

const auth = require('../middleware/authMiddleware');
const rol = require('../middleware/rolMiddleware');

// Rutas públicas
router.post('/registrar', registrarUsuario);
router.post('/login', loginUsuario);
router.post('/logout', logoutUsuario);
router.get('/me', auth, me);

// 🔒 Rutas protegidas (solo Administrador)
router.get('/', auth, rol(['Administrador']), obtenerUsuarios);
router.put('/:id', auth, rol(['Administrador']), actualizarUsuario);
router.delete('/:id', auth, rol(['Administrador']), eliminarUsuario);

module.exports = router;
