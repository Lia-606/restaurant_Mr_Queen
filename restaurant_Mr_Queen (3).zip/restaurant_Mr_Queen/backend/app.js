// ========================================
// app.js - Servidor principal del backend
// ========================================
const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const cors = require('cors');
const morgan = require('morgan');
const path = require('path');

// Cargar variables de entorno (.env dentro de backend)
dotenv.config({ path: path.join(__dirname, '.env') });

// Crear aplicación Express
const app = express();

// Middlewares
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

// ================================
// Conexión a MongoDB
// ================================
const MONGO_URI = process.env.MONGO_URI;

if (!MONGO_URI) {
  console.error('❌ ERROR: No se encontró MONGO_URI en el archivo .env');
  process.exit(1);
}

mongoose
  .connect(MONGO_URI)
  .then(() => console.log('✅ Conectado correctamente a MongoDB'))
  .catch((err) => console.error('❌ Error al conectar a MongoDB:', err.message));

// ================================
// Rutas del backend (API)
// ================================
const usuarioRoutes = require('./routes/usuarioRoutes');
app.use('/api/usuarios', usuarioRoutes);

// ================================
// Servir el frontend (HTML + JS)
// ================================
const frontendPath = path.join(__dirname, '../frontend');

// Servir archivos estáticos (HTML, JS, CSS)
app.use(express.static(frontendPath));
app.use(express.static(path.join(frontendPath, 'public')));

// Página principal (login)
app.get('/', (req, res) => {
  res.sendFile(path.join(frontendPath, 'login.html'));
});

// Dashboard
app.get('/dashboard.html', (req, res) => {
  res.sendFile(path.join(frontendPath, 'public', 'dashboard.html'));
});

// ================================
// Iniciar servidor
// ================================
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`🚀 Servidor backend corriendo en http://localhost:${PORT}`);
});
