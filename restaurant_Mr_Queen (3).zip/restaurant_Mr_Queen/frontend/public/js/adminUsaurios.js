// frontend/public/js/adminUsuarios.js
const tabla = document.getElementById('tablaUsuarios');
const btnFiltrar = document.getElementById('btnFiltrar');
const btnRecargar = document.getElementById('btnRecargar');
const btnBuscar = document.getElementById('btnBuscar');
const formAgregarUsuario = document.getElementById('formAgregarUsuario');

// Verificar autenticación y rol de administrador
window.addEventListener('DOMContentLoaded', async () => {
    await verificarAdmin();
    await cargarUsuarios();
});

async function verificarAdmin() {
    try {
        const res = await fetch('/api/usuarios/me', {
            credentials: 'include'
        });
        
        if (!res.ok) {
            window.location.href = '/';
            return;
        }
        
        const data = await res.json();
        
        // ✅ VERIFICAR QUE SEA ADMINISTRADOR
        if (data.usuario.rol !== 'Administrador') {
            alert('❌ Acceso denegado. Solo administradores pueden acceder a este panel.');
            await fetch('/api/usuarios/logout', { 
                method: 'POST', 
                credentials: 'include' 
            });
            window.location.href = '/';
            return;
        }
        
        // Mostrar info del admin en el navbar
        document.getElementById('userInfo').textContent = 
            `Admin: ${data.usuario.nombre}`;
            
    } catch (error) {
        console.error('Error de autenticación:', error);
        window.location.href = '/';
    }
}

const cargarUsuarios = async (filtros = {}) => {
    try {
        let url = '/api/usuarios';
        const params = new URLSearchParams();
        
        if (filtros.desde && filtros.hasta) {
            params.append('desde', filtros.desde);
            params.append('hasta', filtros.hasta);
        }
        
        if (params.toString()) {
            url += `?${params.toString()}`;
        }

        const res = await fetch(url, { 
            credentials: 'include' 
        });
        
        if (!res.ok) throw new Error('Error al cargar usuarios');
        
        const usuarios = await res.json();

        // Aplicar filtro de nombre si existe
        let usuariosFiltrados = usuarios;
        if (filtros.nombre) {
            usuariosFiltrados = usuarios.filter(u => 
                u.nombre.toLowerCase().includes(filtros.nombre.toLowerCase())
            );
        }

        tabla.innerHTML = usuariosFiltrados.map(u => `
            <tr>
                <td>${u.nombre}</td>
                <td>${u.correo}</td>
                <td>
                    <select class="form-select form-select-sm" onchange="actualizarRol('${u._id}', this.value)">
                        <option value="Administrador" ${u.rol === 'Administrador' ? 'selected' : ''}>Administrador</option>
                        <option value="Mesero" ${u.rol === 'Mesero' ? 'selected' : ''}>Mesero</option>
                        <option value="Cocinero" ${u.rol === 'Cocinero' ? 'selected' : ''}>Cocinero</option>
                        <option value="Cajero" ${u.rol === 'Cajero' ? 'selected' : ''}>Cajero</option>
                        <option value="Recepcionista" ${u.rol === 'Recepcionista' ? 'selected' : ''}>Recepcionista</option>
                    </select>
                </td>
                <td>
                    <select class="form-select form-select-sm" onchange="actualizarEstado('${u._id}', this.value)">
                        <option value="activo" ${u.estado === 'activo' ? 'selected' : ''}>Activo</option>
                        <option value="inactivo" ${u.estado === 'inactivo' ? 'selected' : ''}>Inactivo</option>
                    </select>
                </td>
                <td>${new Date(u.fechaAlta).toLocaleDateString()}</td>
                <td>
                    <button class="btn btn-sm btn-danger" onclick="eliminarUsuario('${u._id}')">🗑️ Eliminar</button>
                </td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error:', error);
        alert('Error al cargar usuarios');
    }
};

// ... el resto del código de adminUsuarios.js se mantiene igual ...
btnFiltrar.onclick = () => {
    const desde = document.getElementById('desde').value;
    const hasta = document.getElementById('hasta').value;
    cargarUsuarios({ desde, hasta });
};

btnBuscar.onclick = () => {
    const nombre = document.getElementById('buscarNombre').value;
    cargarUsuarios({ nombre });
};

btnRecargar.onclick = () => {
    document.getElementById('desde').value = '';
    document.getElementById('hasta').value = '';
    document.getElementById('buscarNombre').value = '';
    cargarUsuarios();
};

// Agregar nuevo usuario (SOLO ADMIN)
formAgregarUsuario.onsubmit = async (e) => {
    e.preventDefault();
    
    const nuevoUsuario = {
        nombre: document.getElementById('nuevoNombre').value,
        correo: document.getElementById('nuevoCorreo').value,
        contrasena: document.getElementById('nuevaContrasena').value,
        rol: document.getElementById('nuevoRol').value
    };

    try {
        const res = await fetch('/api/usuarios/registrar', {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(nuevoUsuario)
        });

        const data = await res.json();

        if (!res.ok) {
            alert(data.mensaje || 'Error al crear usuario');
            return;
        }

        alert('Usuario creado exitosamente');
        formAgregarUsuario.reset();
        cargarUsuarios();
    } catch (error) {
        console.error('Error:', error);
        alert('Error al crear usuario');
    }
};

// Funciones de actualización (SOLO ADMIN)
async function actualizarRol(id, nuevoRol) {
    try {
        const res = await fetch(`/api/usuarios/${id}`, {
            method: 'PUT',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ rol: nuevoRol })
        });

        if (!res.ok) throw new Error('Error al actualizar rol');
        
        alert('Rol actualizado correctamente');
    } catch (error) {
        console.error('Error:', error);
        alert('Error al actualizar rol');
        cargarUsuarios();
    }
}

async function actualizarEstado(id, nuevoEstado) {
    try {
        const res = await fetch(`/api/usuarios/${id}`, {
            method: 'PUT',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ estado: nuevoEstado })
        });

        if (!res.ok) throw new Error('Error al actualizar estado');
        
        alert('Estado actualizado correctamente');
    } catch (error) {
        console.error('Error:', error);
        alert('Error al actualizar estado');
        cargarUsuarios();
    }
}

async function eliminarUsuario(id) {
    if (!confirm('¿Estás seguro de eliminar este usuario? Esta acción no se puede deshacer.')) return;
    
    try {
        const res = await fetch(`/api/usuarios/${id}`, {
            method: 'DELETE',
            credentials: 'include'
        });

        if (!res.ok) throw new Error('Error al eliminar usuario');

        alert('Usuario eliminado correctamente');
        cargarUsuarios();
    } catch (error) {
        console.error('Error:', error);
        alert('Error al eliminar usuario');
    }
}

async function cerrarSesion() {
    try {
        await fetch('/api/usuarios/logout', {
            method: 'POST',
            credentials: 'include'
        });
        window.location.href = '/';
    } catch (error) {
        console.error('Error al cerrar sesión:', error);
        window.location.href = '/';
    }
}