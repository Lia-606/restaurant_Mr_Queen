// frontend/public/js/login.js
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('loginForm');
    const msg = document.getElementById('msg');

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const correo = document.getElementById('correo').value.trim();
        const contrasena = document.getElementById('contrasena').value;

        // Limpiar mensaje anterior
        msg.textContent = '';
        msg.className = '';

        if (!correo || !contrasena) {
            msg.textContent = 'Por favor completa todos los campos';
            msg.className = 'text-center text-danger';
            return;
        }

        msg.textContent = 'Iniciando sesión...';
        msg.className = 'text-center text-info';

        try {
            const response = await fetch('/api/usuarios/login', {
                method: 'POST',
                credentials: 'include',
                headers: { 
                    'Content-Type': 'application/json' 
                },
                body: JSON.stringify({ 
                    correo: correo, 
                    contrasena: contrasena 
                })
            });
            
            const data = await response.json();

            if (!response.ok) {
                msg.textContent = data.mensaje || 'Error al iniciar sesión';
                msg.className = 'text-center text-danger';
                return;
            }

            // ✅ SOLO ADMINISTRADORES PUEDEN ACCEDER
            const rol = data.usuario.rol;
            if (rol !== 'Administrador') {
                msg.textContent = '❌ Solo usuarios administradores pueden acceder al sistema';
                msg.className = 'text-center text-danger';
                
                // Cerrar sesión automáticamente si no es admin
                setTimeout(() => {
                    fetch('/api/usuarios/logout', { 
                        method: 'POST', 
                        credentials: 'include' 
                    });
                }, 2000);
                return;
            }

            msg.textContent = '¡Login exitoso! Redirigiendo al panel de administración...';
            msg.className = 'text-center text-success';

            // Redirigir al dashboard de administrador
            setTimeout(() => {
                window.location.href = '/dashboard.html';
            }, 1000);

        } catch (error) {
            console.error('Error:', error);
            msg.textContent = 'Error de conexión con el servidor';
            msg.className = 'text-center text-danger';
        }
    });
});