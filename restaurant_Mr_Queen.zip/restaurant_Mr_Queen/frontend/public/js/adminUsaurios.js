const tabla = document.getElementById('tablaUsuarios');
const btnFiltrar = document.getElementById('btnFiltrar');
const btnRecargar = document.getElementById('btnRecargar');

const cargarUsuarios = async (desde = '', hasta = '') => {
  let url = 'http://localhost:4000/api/usuarios';
  if (desde && hasta) url += `?desde=${desde}&hasta=${hasta}`;

  const res = await fetch(url, { credentials: 'include' });
  const usuarios = await res.json();

  tabla.innerHTML = usuarios.map(u => `
    <tr>
      <td>${u.nombre}</td>
      <td>${u.correo}</td>
      <td>${u.rol}</td>
      <td>${u.estado}</td>
      <td>${new Date(u.fechaAlta).toLocaleDateString()}</td>
      <td>
        <button class="btn btn-sm btn-warning" onclick="editarUsuario('${u._id}')">✏️</button>
        <button class="btn btn-sm btn-danger" onclick="eliminarUsuario('${u._id}')">🗑️</button>
      </td>
    </tr>
  `).join('');
};

btnFiltrar.onclick = () => {
  const desde = document.getElementById('desde').value;
  const hasta = document.getElementById('hasta').value;
  cargarUsuarios(desde, hasta);
};

btnRecargar.onclick = () => cargarUsuarios();

async function eliminarUsuario(id) {
  if (!confirm('¿Eliminar este usuario?')) return;
  await fetch(`http://localhost:4000/api/usuarios/${id}`, {
    method: 'DELETE',
    credentials: 'include'
  });
  cargarUsuarios();
}

async function editarUsuario(id) {
  const nuevoRol = prompt('Nuevo rol (Administrador, Mesero, Cajero, etc.):');
  if (!nuevoRol) return;
  await fetch(`http://localhost:4000/api/usuarios/${id}`, {
    method: 'PUT',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ rol: nuevoRol })
  });
  cargarUsuarios();
}

// Inicializar
cargarUsuarios();
